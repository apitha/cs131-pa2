package cs131.pa2.CarsTunnels;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

import cs131.pa2.Abstract.Tunnel;
import cs131.pa2.Abstract.Vehicle;
import cs131.pa2.Abstract.Log.Log;

public class PreemptivePriorityScheduler extends Tunnel{
	private ArrayList<LinkedList<Vehicle>> waiting;
	private Collection<Tunnel> tunnels;
	private HashMap<Vehicle, Tunnel> locations;
	private HashMap<Tunnel, ArrayList<Vehicle>> tunnelContents;
	private ReentrantLock lock;
	private Condition condition;
	
	public PreemptivePriorityScheduler(String name, Collection<Tunnel> tunnels, Log log) {
		super(name, log);
		waiting = new ArrayList<LinkedList<Vehicle>>(5);
		for (int i = 0; i < 5; i++) {
			waiting.add(new LinkedList<Vehicle>());
		}
		this.tunnels = tunnels;
		locations = new HashMap<Vehicle, Tunnel>();
		tunnelContents = new HashMap<Tunnel, ArrayList<Vehicle>>();
		// create a new arraylist for each tunnel. Size is 4 because each tunnel will at most
		// have 3 cars and an ambulance
		for (Tunnel tunnel : tunnels) {
			tunnelContents.put(tunnel, new ArrayList<Vehicle>(4));
		}
		lock = new ReentrantLock();
		condition = lock.newCondition();
	}

	@Override
	public boolean tryToEnterInner(Vehicle vehicle) {
		
			return false;
	}

	@Override
	public void exitTunnelInner(Vehicle vehicle) {
		
	}
	
	private void ambulanceTryToEnterInner(Ambulance ambulance) {
		while (true) {
			for (Tunnel tunnel : tunnels) {
				if (!ambulanceInTunnel(tunnel)) {
					for (Vehicle v : tunnelContents.get(tunnel)) {
						v.ambulanceComes();
					}
					tunnelContents.get(tunnel).add(ambulance);
					tunnel.tryToEnter(ambulance);
					tunnelContents.get(tunnel).remove(ambulance);
					for (Vehicle v : tunnelContents.get(tunnel)) {
						v.ambulanceLeaves();
					}
				}
			}
			try {
				condition.await();
			} catch (InterruptedException e) {
				// shouldn't happen
				e.printStackTrace();
			}
		}
	}
	
	private boolean ambulanceInTunnel(Tunnel tunnel) {
		for (Vehicle vehicle : tunnelContents.get(tunnel)) {
			if (vehicle instanceof Ambulance) {
				return true;
			}
		}
		return false;
	}
	
}

