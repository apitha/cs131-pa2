package cs131.pa2.CarsTunnels;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

import cs131.pa2.Abstract.Tunnel;
import cs131.pa2.Abstract.Vehicle;
import cs131.pa2.Abstract.Log.Log;

public class PriorityScheduler extends Tunnel{
	private ArrayList<LinkedList<Vehicle>> waiting;
	private Collection<Tunnel> tunnels;
	private HashMap<Vehicle, Tunnel> locations;
	private ReentrantLock lock;
	private Condition[] priorityWait;

	public PriorityScheduler(String name, Collection<Tunnel> tunnels, Log log) {
		super(name, log);
		waiting = new ArrayList<LinkedList<Vehicle>>(5);
		for (int i = 0; i < 5; i++) {
			waiting.add(new LinkedList<Vehicle>());
		}
		this.tunnels = tunnels;
		locations = new HashMap<Vehicle, Tunnel>();
		lock = new ReentrantLock();
		priorityWait = new Condition[5];
		for (int i = 0; i < 5; i++) {
			priorityWait[i] = lock.newCondition();
		}
	}

	@Override
	public boolean tryToEnterInner(Vehicle vehicle) {
		int priority = vehicle.getPriority();
		lock.lock();
		// check if any higher priority Conditions have threads waiting
		while (true) {
			boolean highestPriority = true;
			for (int i = priority + 1; i < 4; i++) {
				if (lock.getQueueLength() > 0) {
					highestPriority = false;
				}
			}
			if (highestPriority) {
				for (Tunnel tunnel : tunnels) {
					if (tunnel.tryToEnter(vehicle)) {
						//TODO: weird shit going on here
						locations.put(vehicle, tunnel);
						lock.unlock();
						return true;
					}
				}
				try {
					priorityWait[priority].await();
				} catch (InterruptedException e) {
					// shouldn't happen
					e.printStackTrace();
				}
			}
		}
	}

	@Override
	public void exitTunnelInner(Vehicle vehicle) {
		lock.lock();
		Tunnel tunnel = locations.get(vehicle);
		if (tunnel != null) {
			tunnel.exitTunnel(vehicle);
			locations.remove(vehicle);
		}
		lock.unlock();
	}

}
