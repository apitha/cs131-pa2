Eli Esrig and Addison Pitha
elazare@brandeis.edu and apitha@brandeis.edu

This task was short enough that we didn't divide up the work, we just talked it through and
wrote it out together, so we distributed it as evenly as can be, and both understand why we
made all of our decisions.