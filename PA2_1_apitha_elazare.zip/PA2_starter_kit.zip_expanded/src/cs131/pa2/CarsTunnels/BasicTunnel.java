package cs131.pa2.CarsTunnels;

import cs131.pa2.Abstract.Direction;
import cs131.pa2.Abstract.Tunnel;
import cs131.pa2.Abstract.Vehicle;

public class BasicTunnel extends Tunnel{
	private int slots;
	private Direction direction;
	
	
	public BasicTunnel(String name) {
		super(name);
		slots = 3;
		direction = null;
	}

	@Override
	public synchronized boolean tryToEnterInner(Vehicle vehicle) {
		// sleds take up all 3 slots, so sleds and cars can't be present at the same time
		if(vehicle instanceof Sled) {
			if(slots >= 3) {
				slots -= 3;
				direction = vehicle.getDirection();
				return true;
			}else {
				return false;
			}
		}else if(vehicle instanceof Car) {
			if(slots >= 3) {
				// if 3 slots, the tunnel is empty, so any car can enter
				slots --;
				direction = vehicle.getDirection();
				return true;
			}else if(0 < slots && vehicle.getDirection().equals(direction)) {
				// if 1 or 2 slots and the direction is correct, the car can enter
				slots--;
				return true;
			}else {
				// no space in the tunnel, or not going the right direction
				return false;
			}
		}else {
			// vehicle is and ambulance
			return true;
		}
	}

	@Override
	public synchronized void exitTunnelInner(Vehicle vehicle) {
		// free up the correct number of keys into the semaphore
		if(vehicle instanceof Sled) {
			slots += 3;
		}else if(vehicle instanceof Car) {
			slots++;
		}
	}
	
}
